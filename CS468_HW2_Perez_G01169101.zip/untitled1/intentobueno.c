//
// Created by Andrea Pérez Isla on 11/10/18.
//

#include <stdio.h>
#include <string.h>
#include <openssl/des.h>
#include <string.h>
#include "main.h"
#define LONG_MAX_LINEA 1024

int main(int argc, char *argv[]) { //comprobar los parametros de la funcion main

    FILE *Llavecita = fopen(argv[3], "rt");
    char cadena1[100];
    fgets(cadena1, 100, Llavecita);
    fclose(Llavecita);
    //la llave que me dan tiene 16 bytes

    FILE *FicheroaEncriptar;
    FicheroaEncriptar = fopen(argv[5], "r");
    unsigned char linea[8];

    printf("Program to encrypt in DES ECB mode\n");

    DES_cblock keyy;
    DES_string_to_key(cadena1, &keyy);  //el primer parametro lo meto yo, el segundo es donde se mete la informacion
    DES_key_schedule schedule;
    DES_set_key_checked(&keyy, &schedule);

    while(fgets(linea,8, FicheroaEncriptar) != NULL){
        printf("%s", linea);
        const_DES_cblock input;

        for(int i =0; i < 8; i++){
            strcpy(input[i], linea[i]);
        }




        DES_cblock encrypted ;
        DES_ecb_encrypt(&input, &encrypted, &schedule, DES_ENCRYPT);
        int i;
        for (i = 0; i < sizeof(const_DES_cblock); i++)
            printf("%02x", encrypted[i]);
        printf(" ");


    }

    //CERRAR LOS ARCHIVOS CON FCLOSE?
    printf("The plaintext was succesfully encrypted \n");
    fclose(FicheroaEncriptar);



    return 0;




//printf("ciphertext: \n");
//while (!feof(FicheroEncriptado))
//   printf("%c", getc(FicheroEncriptado));
//DES_key_schedule keysched = Llave;
//COMPROBAR LOS PERMISOS DE AQUI ARRIBA Y LAS CONDICIONES DE LOS IF



//if (argc == 1)  {
//  printf("Parameters are missing...\n");
//return 1;
//}
//if (argc > 8){
//  printf("Too many parameters\n");
// return 1;
//}
//if (strcmp(argv[1],"DES_ECB_Enc") != 0 || strcmp(argv[2],"-k") != 0 || strcmp(argv[4],"-i") != 0 || strcmp(argv[6],"-o") != 0){
//   printf("You didnt put the commands correctly \n");
// return 1;
//}
//if (FicheroaEncriptar == NULL || Llavecita == NULL || FicheroEncriptado == NULL){
//   perror("Error trying to open the file\n");
// return -1;
//}









//printf("%s has successfully been encrypted with %s key in %s file", argv[5], argv[3], argv[7]);  //comprobar las letras de %
//return 0;
}