#include <stdio.h>
#include <string.h>
#include <openssl/des.h>
#include <string.h>
#include "main.h"


int main(int argc, char *argv[]) { //comprobar los parametros de la funcion main
    //FILE* FicheroaEncriptar = fopen(argv[5],"r");
    //char ficherito[900];
    //fgets(ficherito, 900, FicheroaEncriptar);

    //CERRAR LOS ARCHIVOS CON FCLOSE?

    FILE* Llavecita = fopen(argv[3],"rt");
    char cadena1[16];
    fgets(cadena1, 16, Llavecita);

    //la llave que me dan tiene 16 bytes


    printf("Program to encrypt in DES ECB mode\n");


    DES_cblock keyy;
    DES_string_to_key(cadena1,&keyy);  //el primer parametro lo meto yo, el segundo es donde se mete la informacion
    DES_key_schedule schedule;
    DES_set_key_checked(&keyy, &schedule);
    //printf("%s",ficherito);

    const_DES_cblock plaintext = "This hom";
    DES_cblock encrypted;

    printf("cleartext:%s \n", plaintext);

    DES_ecb_encrypt(&plaintext, &encrypted, &schedule, DES_ENCRYPT);
    printf("The plaintext was succesfully encrypted \n");
    printf("ciphertext:\n");
    int i;
    for (i=0; i < sizeof(plaintext); i++)
        printf(" %u ", encrypted[i]);
    printf(" ");




    return 0;




    //printf("ciphertext: \n");
    //while (!feof(FicheroEncriptado))
     //   printf("%c", getc(FicheroEncriptado));
    //DES_key_schedule keysched = Llave;
    //COMPROBAR LOS PERMISOS DE AQUI ARRIBA Y LAS CONDICIONES DE LOS IF



    //if (argc == 1)  {
      //  printf("Parameters are missing...\n");
        //return 1;
    //}
    //if (argc > 8){
      //  printf("Too many parameters\n");
       // return 1;
    //}
    //if (strcmp(argv[1],"DES_ECB_Enc") != 0 || strcmp(argv[2],"-k") != 0 || strcmp(argv[4],"-i") != 0 || strcmp(argv[6],"-o") != 0){
     //   printf("You didnt put the commands correctly \n");
       // return 1;
    //}
    //if (FicheroaEncriptar == NULL || Llavecita == NULL || FicheroEncriptado == NULL){
     //   perror("Error trying to open the file\n");
       // return -1;
    //}









    //printf("%s has successfully been encrypted with %s key in %s file", argv[5], argv[3], argv[7]);  //comprobar las letras de %
    //return 0;
}