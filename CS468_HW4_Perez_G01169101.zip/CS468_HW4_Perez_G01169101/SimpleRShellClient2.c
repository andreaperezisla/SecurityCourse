/* 

  SimpleRShellClient.c

  Created by Xinyuan Wang for CS 468
 
  All rights reserved.
*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <ifaddrs.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/errno.h>
#include <string.h>
#include <openssl/sha.h>
#include <openssl/conf.h>
#include <openssl/evp.h>
#include <openssl/err.h>

//#define DEBUG

typedef struct mensaje 
{ 	
	//int messagetype;
	//int payloadlength[2];
    char id[16]; 
    char shellcommand[100]; 
}mensaje; 

typedef struct sms1{
	//int messagetype;
	//int payloadlength[2];
    char id[16]; 
    int Nonce1; 
}sms1;

typedef struct sms2{
	//int messagetype;
	//int payloadlength[2];
    char id[16]; 
    int Nonce2;
}sms2;

typedef struct sms3{
	//int messagetype;
	//int payloadlength[2];
    char id[16]; 
    char ciphertext[128];
    int ciphertext_len;
}sms3;

typedef struct sms4{
	char messagetype[2];
	//int messagetype;
	//int payloadlength[2];
    char id[16]; 
    char ciphertext[128];
    int ciphertext_len;
}sms4;

typedef struct mensaje2 
{ 	
	char messagetype[2];
	//int payloadlength[2];
    char id[16]; 
}mensaje2; 

typedef struct mensaje3 
{ 	
	//int messagetype;
	//int payloadlength[2];
    char id[16]; 
    char shaw1password[SHA_DIGEST_LENGTH*2]; 
}mensaje3;   

void handleErrors(void)
{
  ERR_print_errors_fp(stderr);
  abort();
}

int encrypt2(unsigned char *plaintext, int plaintext_len, unsigned char *key,
  unsigned char *iv, unsigned char *ciphertext)
{
  EVP_CIPHER_CTX *ctx;

  int len;

  int ciphertext_len;

  /* Create and initialise the context */
  if(!(ctx = EVP_CIPHER_CTX_new())) handleErrors();

  /* Initialise the encryption operation*/
  if(1 != EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv))
    handleErrors();

  /* Provide the message to be encrypted, and obtain the encrypted output.
   */
  if(1 != EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len))
    handleErrors();
  ciphertext_len = len;

  if(1 != EVP_EncryptFinal_ex(ctx, ciphertext + len, &len)) handleErrors();
  ciphertext_len += len;

  EVP_CIPHER_CTX_free(ctx);

  return ciphertext_len;
}

int decrypt2(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
  unsigned char *iv, unsigned char *plaintext)
{
  EVP_CIPHER_CTX *ctx;

  int len;

  int plaintext_len;

  /* Create and initialise the context */
  if(!(ctx = EVP_CIPHER_CTX_new())) handleErrors();

  /* Initialise the decryption operation. */
  if(1 != EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv))
    handleErrors();

  /* Provide the message to be decrypted, and obtain the plaintext output.
   */
  if(1 != EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len))
    handleErrors();
  plaintext_len = len;

  if(1 != EVP_DecryptFinal_ex(ctx, plaintext + len, &len)) handleErrors();
  plaintext_len += len;

  EVP_CIPHER_CTX_free(ctx);

  return plaintext_len;
}






int
clientsock(int UDPorTCP, const char *destination, int portN)
{
	struct hostent	*phe;		/* pointer to host information entry	*/
	struct sockaddr_in dest_addr;	/* destination endpoint address		*/
	int    sock;			/* socket descriptor to be allocated	*/


	bzero((char *)&dest_addr, sizeof(dest_addr));
	dest_addr.sin_family = AF_INET;

    /* Set destination port number */
	dest_addr.sin_port = htons(portN);

    /* Map host name to IPv4 address, does not work well for IPv6 */
	if ( (phe = gethostbyname(destination)) != 0 )
		bcopy(phe->h_addr, (char *)&dest_addr.sin_addr, phe->h_length);
	else if (inet_aton(destination, &(dest_addr.sin_addr))==0) /* invalid destination address */
		return -2;

/* version that support IPv6 
	else if (inet_pton(AF_INET, destination, &(dest_addr.sin_addr)) != 1) 
*/

    /* Allocate a socket */
	sock = socket(PF_INET, UDPorTCP, 0);
	if (sock < 0)
		return -3;

    /* Connect the socket */
    printf("*******CONNECTING TO SERVER*********\n");
	if (connect(sock, (struct sockaddr *)&dest_addr, sizeof(dest_addr)) < 0)
		return -4;

	return sock;
}

inline int clientTCPsock(const char *destination, int portN) 
{
  return clientsock(SOCK_STREAM, destination, portN);
}


inline int clientUDPsock(const char *destination, int portN) 
{
  return clientsock(SOCK_DGRAM, destination, portN);
}

#define	LINELEN		128
#define resultSz	4096

void usage(char *self)
{
	fprintf(stderr, "Usage: %s destination port id password\n", self);
	exit(1);
}

void errmesg(char *msg)
{
	fprintf(stderr, "**** %s\n", msg);
	exit(1);

}

/*------------------------------------------------------------------------------
 * TCPrecv - read TCP socket sock w/ flag for up to buflen bytes into buf

 * return:
	>=0: number of bytes read
	<0: error
 *------------------------------------------------------------------------------
 */
int
TCPrecv(int sock, char *buf, int buflen, int flag)
{
	int inbytes, n;

	if (buflen <= 0) return 0;

  /* first recv could be blocking */
	inbytes = 0; 
	n=recv(sock, &buf[inbytes], buflen - inbytes, flag);
	if (n<=0 && n != EINTR)
		return n;

	buf[n] = 0;

#ifdef DEBUG
	printf("\tTCPrecv(sock=%d, buflen=%d, flag=%d): first read %d bytes : `%s`\n", 
			   sock, buflen, flag, n, buf);
#endif /* DEBUG */

  /* subsequent tries for for anything left available */

	for (inbytes += n; inbytes < buflen; inbytes += n)
	{ 
	 	if (recv(sock, &buf[inbytes], buflen - inbytes, MSG_PEEK|MSG_DONTWAIT)<=0) /* no more to recv */
			break;
	 	n=recv(sock, &buf[inbytes], buflen - inbytes, MSG_DONTWAIT);
		buf[n] = 0;
		
#ifdef DEBUG
		printf("\tTCPrecv(sock=%d, buflen=%d, flag=%d): subsequent read %d bytes : `%s`\n", 
			   sock, buflen, flag, n, &buf[inbytes]);
#endif /* DEBUG */

	  if (n<=0) /* no more bytes to receive */
		break;
	};

#ifdef DEBUG
		printf("\tTCPrecv(sock=%d, buflen=%d): read totally %d bytes : `%s`\n", 
			   sock, buflen, inbytes, buf);
#endif /* DEBUG */

	return inbytes;
}

int
RemoteShell(char *destination, int portN, char id[16], char password[20])
{ //confirmar los tipos de id y password
	char	buf[LINELEN+1];		/* buffer for one line of text	*/
	char	buf2[SHA_DIGEST_LENGTH*2];	
	char	result[resultSz+2];
	int	sock;				/* socket descriptor, read count*/


	int	outchars, inchars;	/* characters sent and received	*/
	int n,entero,i,n2;
	struct mensaje mensaje;
	struct mensaje2 mensaje2;
	struct mensaje3 mensaje3;
	struct sms1 sms1;
	struct sms2 sms2;
	struct sms3 sms3;
	struct sms4 sms4;
	unsigned char resultshaw[SHA_DIGEST_LENGTH];

	if ((sock = clientTCPsock(destination, portN)) < 0)
		errmesg("fail to obtain TCP socket");

	while (fgets(buf, sizeof(buf), stdin)) 
	{
		buf[LINELEN] = '\0';	/* insure line null-terminated	*/
		outchars = strlen(buf);
		strcpy(mensaje.shellcommand,buf);
		fflush(stdin);
		strcpy(mensaje.id,id);
		//strcpy(mensaje.messagetype,"1");
		//strcpy(mensaje.payloadlength,sizeof(mensaje));
		printf("*******COMMAND SENT ********* : %s\n", mensaje.shellcommand);
		printf("*******USER ID ********* : %s\n", mensaje.id);
		//printf("the type of message sent is : %s\n", mensaje.messagetype);
		//printf("payload length is : %s\n", mensaje.payloadlength);

		//esto de aqui arriba crea el mensaje con el comando pero para el HW4 no me piden eso en el primer mensaje
		unsigned int Nonce1;
		Nonce1=rand()%9000 +1000;

		sms1.Nonce1=Nonce1;
		strcpy(sms1.id,id);
		printf("Nonce1 number created is: %d , sent to the server with the id \n", (unsigned int)sms1.Nonce1);
		//tengo en mensaje el id y el comando que quiero, lo dejo ahi, ahora necesito mandar el numero random

		if ((n=write(sock, &sms1, sizeof(sms1)))!=sizeof(sms1))	/* send error */
		{
		#ifdef DEBUG
			printf("RemoteShell(%s, %d): has %d byte send when trying to send %d bytes to RemoteShell: `%s`\n", 
			   destination, portN, n, outchars, buf);
		#endif /* DEBUG */
			close(sock);
			return -1;
		}
		#ifdef DEBUG
		printf("RemoteShell(%s, %d): sent %d bytes to RemoteShell: `%s`\n", 
			   destination, portN, n, buf);
		#endif /* DEBUG */


		//AQUI ABAJO RECIBO EL NONCE2

		if ((inchars=recv(sock,&sms2,sizeof(sms2),0))>0)
		{
			printf("*******RECEIVED NONCE2 FROM SERVER : %d \n", sms2.Nonce2);
			printf("*******FROM USER *********: %s\n", sms2.id);
		}
			buf[LINELEN]='\0';
			outchars = strlen(buf2);
			buf2[SHA_DIGEST_LENGTH*2]='\0';
			fflush(stdin);
			 memset(buf2, 0x0, SHA_DIGEST_LENGTH*2);
    		 memset(resultshaw, 0x0, SHA_DIGEST_LENGTH);
 
   			 SHA1((unsigned char *)password, strlen(password), resultshaw);
 
    		for (i=0; i < SHA_DIGEST_LENGTH; i++) {
        		sprintf((char*)&(buf2[i*2]), "%02x", resultshaw[i]);
    		}
    		printf("*******SHA1 PASSWORD CALCULATED*********: %s\n",buf2);

    		//ESTO DE AQUI ARRIBA LO SIGO NECESITANDO PORQUE ME PIDE LA SHA1 DE LA CONTRASEÑA INTRODUCIDA
    		int numerin;
    		int Nonce2;
    		Nonce2=sms2.Nonce2;
    		numerin=Nonce2+1;
    		char Nonce2maschar[32];
    		char Nonce1char[32];
    		char Nonce2char[32];
    		char concatNonce1Nonce2[32]="";
    		char concatShawNonce1Nonce2[100]="";
    		char concatNonce2mas1Comando[32]="";
			sprintf(Nonce2maschar, "%d", numerin);
			sprintf(Nonce1char,"%d",Nonce1);
			sprintf(Nonce2char,"%d",Nonce2);
			char comando[100];
			strcpy(comando,mensaje.shellcommand);
			
			for(int i = 0;i<sizeof(comando);i++){
				if(comando[i]=='\n'){
					comando[i]='\0';
				}
			}

			//ESTO DE AQUI ABAJO LO HACE BIEN
			strcat(concatShawNonce1Nonce2,buf2);
			strcat(concatShawNonce1Nonce2,Nonce1char);
			strcat(concatShawNonce1Nonce2,Nonce2char);
			//printf("concatenar shaw nonce1 nonce2: %s\n",concatShawNonce1Nonce2);
			strcat(concatNonce2mas1Comando,Nonce2maschar);
			strcat(concatNonce2mas1Comando,comando);
			//printf("concatenar nonce2+1 comando: %s\n",concatNonce2mas1Comando );
			strcat(concatNonce1Nonce2,Nonce1char);
			strcat(concatNonce1Nonce2,Nonce2char);
			//printf("concatenar nonce1 nonce2 : %s\n",concatNonce1Nonce2);
			//strcat(comando, Nonce2maschar);
			//printf("%s\n",comando);

			char buf3[SHA_DIGEST_LENGTH*2];
			unsigned char resultshaw256key[SHA_DIGEST_LENGTH];

			//AQUI CALCULO PRIMERO LA LLAVE QUE NECESITO
			//buf[LINELEN]='\0';
			//outchars = strlen(buf3);
			buf3[SHA_DIGEST_LENGTH*2]='\0';
			fflush(stdin);
			memset(buf3, 0x0, SHA_DIGEST_LENGTH*2);
    		memset(resultshaw256key, 0x0, SHA_DIGEST_LENGTH);
 
   			SHA256((unsigned char *)concatShawNonce1Nonce2, strlen(concatShawNonce1Nonce2), resultshaw256key);
 
    		for (i=0; i < SHA_DIGEST_LENGTH; i++) {
        		sprintf((char*)&(buf3[i*2]), "%02x", resultshaw256key[i]);
    		}
    		printf("*******SHA256 CALCULATED, THIS IS THE KEY *********: %s\n",buf3);


    		char buf4[SHA_DIGEST_LENGTH*2];
			unsigned char resultshaw256iv[SHA_DIGEST_LENGTH];

    		//AQUI CALCULO DESPUES EL IV DEL ENCRIPTADO, LOS 128 BITS(16 BYTES) DEL SHA256 DE NONCE1 Y NONCE2
			//buf[LINELEN]='\0';
			//outchars = strlen(buf4);
			buf4[SHA_DIGEST_LENGTH*2]='\0';
			fflush(stdin);
			memset(buf4, 0x0, SHA_DIGEST_LENGTH*2);
    		memset(resultshaw256iv, 0x0, SHA_DIGEST_LENGTH);
 
   			SHA256((unsigned char *)concatNonce1Nonce2, strlen(concatNonce1Nonce2), resultshaw256iv);
 
    		for (i=0; i < SHA_DIGEST_LENGTH; i++) {
        		sprintf((char*)&(buf4[i*2]), "%02x", resultshaw256iv[i]);
    		}


    		char buf4cortado[18];
    		strncpy(buf4cortado,buf4,16);
    		buf4cortado[16]='\0';
    		//printf("*******SHA256 CALCULATED, THIS IS THE IV *********: %s\n",buf4);
    		printf("*******SHA256 CALCULATED, THIS IS THE IV *********: %s\n",buf4cortado);


    		//AQUI EMPIEZA YA EL ENCRIPTADO
    		unsigned char *key = (unsigned char *)buf3;
    		unsigned char *iv = (unsigned char *)buf4cortado;
    		unsigned char *plaintext = (unsigned char *)concatNonce2mas1Comando;

    		/* Buffer for ciphertext.*/
 			unsigned char ciphertext[128];

  			int ciphertext_len;

  			ciphertext_len = encrypt2(plaintext, strlen ((char *)plaintext), key, iv,
                            ciphertext);

 			
  			printf("Ciphertext (in this case, the Nonce2+1 and the command) is:\n");
  			BIO_dump_fp (stdout, (const char *)ciphertext,ciphertext_len);
  			
  			strcpy(sms3.id,id);
  			strcpy(sms3.ciphertext,ciphertext);
  			sms3.ciphertext_len=ciphertext_len;
  			printf("Sending the encrypted message and the id*****\n");


    		if ((n2=write(sock, &sms3, sizeof(sms3)))!=sizeof(sms3))	/* send error */
		{
			#ifdef DEBUG
					printf("RemoteShell(%s, %d): has %d byte send when trying to send %d bytes to RemoteShell: `%s`\n", 
			   			destination, portN, n, outchars, buf);
			#endif /* DEBUG */
					close(sock);
					return -1;
		}
			
			//recibo el sms4, puede ser ok o no ok
			int inchars2;
			if ((inchars2=recv(sock,&sms4,sizeof(sms4),0))>0)
		{
			printf("*******RECEIVED AUTHENTICATION MESSAGE FROM SERVER*********\n");
			printf("*******LETS SEE IF IT IS CORRECT OR INCORRECT*********\n");
			//printf("the type of message received is: %s\n",mensaje2.messagetype);
			if(strcmp(sms4.messagetype,"5")==0){
				printf("*******AUTHENTICATION FAILED, EXIT*********\n");
				close(sock);
				return 0;
			}else{
				//SI EL MENSAJE QUE LLEGA ES SUCCESS, TIPO4, DESENCRIPTAR HASTA CONSEGUIR NONCE+1 Y
				//VER SI LO QUE ME HA LLEGADO ES IGUAL QUE MI NONCE1

				//A PARTIR DE AQUI VOY A DESENCRIPTAR LO QUE ME HAN MANDADO	
				
  				unsigned char decryptedtext[128];

			
				int decryptedtext_len;
  				decryptedtext_len = decrypt2(sms4.ciphertext, sms4.ciphertext_len, key, iv, decryptedtext);

  				
  				decryptedtext[decryptedtext_len] = '\0';

  				
  				printf("Decrypted text of Nonce1+1 is:\n");
  				printf("%s\n", decryptedtext);	

  				//AQUI SACO EL NUMERO NONCE1
  				char Nonce1mascharrecibido[32];
  				strncpy(Nonce1mascharrecibido,decryptedtext,4);
  				Nonce1mascharrecibido[4]='\0';
  				//printf("el nonce1masuno recibido es: %s\n", Nonce2mascharrecibido);

		  		//PASAR DE CHAR A INT PARA PODER RESTARLE UNO AL NUMERO Y COMPROBAR SI ES ESE EL QUE MANDE
  				int ultimodigito = (unsigned int) Nonce1mascharrecibido[3];
  				ultimodigito--;
  				Nonce1mascharrecibido[3]=(unsigned char)ultimodigito;
  				Nonce1mascharrecibido[4]='\0';
  				printf("Nonce1 received is: %s \n",Nonce1mascharrecibido);


  				if(strcmp(Nonce1char,Nonce1mascharrecibido)==0){
  					printf("*******NONCE1 IS CORRECT*********\n");
  					printf("*******RECEIVING THE EXECUTION FROM THE SERVER*********\n");
  				}else{
  					printf("*******NONCE1 IS NOT CORRECT*********\n");
  					close(sock);
					return 0;
  				}


			}
		}

			int inchars3;
			/* Get the result */

			if ((inchars3=recv(sock, result, resultSz, 0))>0) /* got some result */
			{  
				result[inchars3]=0;	
				fflush(stdout);
				fputs(result, stdout);	
				//printf("he recibido algo del servidor\n");		
			}
			if (inchars < 0)
				errmesg("socket read failed\n");
	}

	close(sock);
	return 0;
}

/*------------------------------------------------------------------------
 * main  *------------------------------------------------------------------------
 */
int
main(int argc, char *argv[])
{
	char *destination;
	int  portN,p;
	char id[16];
	char password;
	struct mensaje mensaje;
	struct mensaje3 mensaje3;

	srand (getpid());

	if (argc==5)
	{ 
	  destination = argv[1];
	  portN = atoi(argv[2]);
	  strcpy(mensaje.id,argv[3]);
	  strcpy(mensaje3.shaw1password,argv[4]);
	  if(strcmp(mensaje.id,"Alice")!=0){
	  	printf("*******USER NOT RECOGNIZED*********\n");
	  	exit(0);
	  }
	  if(strcmp(mensaje3.shaw1password,"SecretPW")!=0){
	  	printf("****** This password is not defined in passwdfile.txt\n");
	  }
	  
	}
	else usage(argv[0]);
		
	RemoteShell(destination, portN, mensaje.id, mensaje3.shaw1password);

	exit(0);
}


