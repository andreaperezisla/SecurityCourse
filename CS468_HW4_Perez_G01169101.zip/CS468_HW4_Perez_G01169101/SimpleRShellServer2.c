/* 

  SimpleRShellServer.c

  Created by Xinyuan Wang for CS 468

  All rights reserved.

*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <ifaddrs.h>
#include <strings.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/errno.h>
#include <openssl/sha.h>
#include <openssl/conf.h>
#include <openssl/evp.h>
#include <openssl/err.h>

#define DEBUG

typedef struct mensaje 
{ 	
	//int messagetype;
	//int payloadlength[2];
    char id[16]; 
    int shellcommand[100]; 
}mensaje;

typedef struct sms1{
	//int messagetype;
	//int payloadlength[2];
    char id[16]; 
    int Nonce1;
}sms1;

typedef struct sms2{
	//int messagetype;
	//int payloadlength[2];
    char id[16]; 
    int Nonce2;
}sms2;

typedef struct sms3{
	//int messagetype;
	//int payloadlength[2];
    char id[16]; 
    char ciphertext[128];
    int ciphertext_len;
}sms3;

typedef struct sms4{
	char messagetype[2];
	//int messagetype;
	//int payloadlength[2];
    char id[16]; 
    char ciphertext[128];
    int ciphertext_len;
}sms4;

typedef struct mensaje2 
{ 	
	char messagetype[2];
	//int payloadlength[2];
    char id[16]; 
    //int shellcommand[100]; sin esto aqui 
}mensaje2;  

typedef struct mensaje3 
{ 	
	//int messagetype;
	//int payloadlength[2];
    char id[16]; 
    char shaw1password[SHA_DIGEST_LENGTH*2]; //mirar lo que significa lo de tratarlo como un raw byte stream 
}mensaje3; 


/*FUNCIONES QUE UTLILZO, COMO LA DE ENCRIPTAR Y DESENCRIPTAR, APARTE DE MANEJO DE ERRORES INCLUIDO*/

void handleErrors(void)
{
  ERR_print_errors_fp(stderr);
  abort();
}


int encrypt2(unsigned char *plaintext, int plaintext_len, unsigned char *key,
  unsigned char *iv, unsigned char *ciphertext)
{
  EVP_CIPHER_CTX *ctx;

  int len;

  int ciphertext_len;

  /* Create and initialise the context */
  if(!(ctx = EVP_CIPHER_CTX_new())) handleErrors();

  /* Initialise the encryption operation*/
  if(1 != EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv))
    handleErrors();

  /* Provide the message to be encrypted, and obtain the encrypted output.
   */
  if(1 != EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len))
    handleErrors();
  ciphertext_len = len;


  if(1 != EVP_EncryptFinal_ex(ctx, ciphertext + len, &len)) handleErrors();
  ciphertext_len += len;

  
  EVP_CIPHER_CTX_free(ctx);

  return ciphertext_len;
}


int decrypt2(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
  unsigned char *iv, unsigned char *plaintext)
{
  EVP_CIPHER_CTX *ctx;

  int len;

  int plaintext_len;


  if(!(ctx = EVP_CIPHER_CTX_new())) handleErrors();

  /* Initialise the decryption operation */
  if(1 != EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv))
    handleErrors();

  /* Provide the message to be decrypted, and obtain the plaintext output.
   */
  if(1 != EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len))
    handleErrors();
  plaintext_len = len;

  
  if(1 != EVP_DecryptFinal_ex(ctx, plaintext + len, &len)) handleErrors();
  plaintext_len += len;


  EVP_CIPHER_CTX_free(ctx);

  return plaintext_len;
}


int
serversock(int UDPorTCP, int portN, int qlen)
{
	struct sockaddr_in svr_addr;	/* my server endpoint address		*/
	int    sock;			/* socket descriptor to be allocated	*/

	if (portN<0 || portN>65535 || qlen<0)	/* sanity test of parameters */
		return -2;

	bzero((char *)&svr_addr, sizeof(svr_addr));
	svr_addr.sin_family = AF_INET;
	svr_addr.sin_addr.s_addr = INADDR_ANY;

    /* Set destination port number */
	svr_addr.sin_port = htons(portN);

    /* Allocate a socket */
	sock = socket(PF_INET, UDPorTCP, 0);
	if (sock < 0)
		return -3;

    /* Bind the socket */
	if (bind(sock, (struct sockaddr *)&svr_addr, sizeof(svr_addr)) < 0)
		return -4;

	if (UDPorTCP == SOCK_STREAM && listen(sock, qlen) < 0)
		return -5;

	return sock;
}

inline int serverTCPsock(int portN, int qlen) 
{
  return serversock(SOCK_STREAM, portN, qlen);
}

inline int serverUDPsock(int portN) 
{
  return serversock(SOCK_DGRAM, portN, 0);
}

void usage(char *self)
{
	fprintf(stderr, "Usage: %s port passwdfile\n", self);
	exit(1);
}

void errmesg(char *msg)
{
	fprintf(stderr, "**** %s\n", msg);
	exit(1);

}

/*------------------------------------------------------------------------
 * reaper - clean up zombie children
 *------------------------------------------------------------------------
 */
void
reaper(int signum)
{
/*
	union wait	status;
*/

	int status;

	while (wait3(&status, WNOHANG, (struct rusage *)0) >= 0)
		/* empty */;
}

/*------------------------------------------------------------------------
 *  This is a very simplified remote shell, there are some shell command it 
	can not handle properly:

	cd
 *------------------------------------------------------------------------
 */
int
RemoteShellD(int sock)
{
#define	BUFSZ		128
#define resultSz	4096
	char cmd[BUFSZ+20];
	char result[resultSz];
	int	cc, len, n, cc2,i;
	int rc=0;
	FILE *fp;
	struct mensaje mensaje;
	struct mensaje2 mensaje2;
	struct sms1 sms1;
	struct sms2 sms2;
	struct sms3 sms3;
	struct sms4 sms4;
	char buf2[SHA_DIGEST_LENGTH*2];

#ifdef DEBUG
	printf("***** RemoteShellD(sock=%d) called\n", sock);
#endif
	printf("*******RECEIVING SOMETHING FROM THE CLIENT *********\n");

	while ((cc = read(sock, &sms1, sizeof(sms1))) > 0)	/* received something */
	{	//printf("entro en lo que leo\n");
		//strcpy(cmd, mensaje.shellcommand);
		printf("*******NONCE1 RECEIVED *********: %d\n", sms1.Nonce1);
		printf("*******FROM USER *********: %s\n", sms1.id);
		//printf("the type of message received is: %s\n", mensaje.messagetype);
		//printf("payload length is : %s\n", mensaje.payloadlength);
	

		strcpy(mensaje2.id,sms1.id);
		//strcpy(mensaje2.messagetype,"2");
		unsigned int Nonce2;
		Nonce2=rand()%9000 +1000;
		sms2.Nonce2=Nonce2;
		strcpy(sms2.id,sms1.id);
		printf("Nonce2 number created: %d , sent to the client with the id \n", (unsigned int)sms2.Nonce2);
		
	if ((n=write(sock, &sms2, sizeof(sms2)))!=sizeof(sms2))	/* send error */
		{
	#ifdef DEBUG
			printf("WRONG\n");
	#endif /* DEBUG */
			close(sock);
			return -1;
		}

		memset(buf2, 0x0, SHA_DIGEST_LENGTH*2);

		while ((cc2 = read(sock, &sms3, sizeof(sms3))) > 0)	/* received something */
	{	buf2[SHA_DIGEST_LENGTH*2]='\0';	
		printf("*******MESSAGE ENCRYPTED RECEIVED FROM CLIENT*********\n");
		printf("from user: %s\n", sms3.id);


		//ESTO DE AQUI ABAJO LO HAGO PARA COGER LA SHA1 DE LA PASSWORD
  		//A PARTIR DEL DOCUMENTO
		char linea1[103];
		char linea2[1024];
   		FILE *fich;
	 		
    	fich = fopen("passwdfile.txt", "r");
    	fgets(linea1, 103, (FILE*) fich);
    	fgets(linea2, 1024, (FILE*) fich);
    	fclose(fich);
    	printf("The password read from the file is: %s \n",linea2);

    	//Y AHORA NECESITO LA KEY Y LA IV PARA DESENCRIPTAR
    	//LA CONCATENACION DEL COMANDO NO LA HE PUESTO PORQUE NO LA NECESITO
    	int numerin;
    	int Nonce1;
    	Nonce1=sms1.Nonce1;
    	numerin=Nonce2+1;
    	char Nonce2maschar[32];
    	char Nonce1char[32];
    	char Nonce2char[32];
   		char concatNonce1Nonce2[32]="";
   		char concatShawNonce1Nonce2[100]="";
   		char concatNonce2mas1Comando[32]="";
		sprintf(Nonce2maschar, "%d", numerin);
		sprintf(Nonce1char,"%d",Nonce1);
		sprintf(Nonce2char,"%d",Nonce2);


		strcat(concatShawNonce1Nonce2,linea2);
		strcat(concatShawNonce1Nonce2,Nonce1char);
		strcat(concatShawNonce1Nonce2,Nonce2char);
		//printf("concatenar shaw nonce1 nonce2: %s\n",concatShawNonce1Nonce2);
			
		strcat(concatNonce1Nonce2,Nonce1char);
		strcat(concatNonce1Nonce2,Nonce2char);
		//printf("concatenar nonce1 nonce2 : %s\n",concatNonce1Nonce2);

		char buf3[SHA_DIGEST_LENGTH*2];
		unsigned char resultshaw256key[SHA_DIGEST_LENGTH];
		//AQUI CALCULO PRIMERO LA LLAVE QUE NECESITO
		buf3[SHA_DIGEST_LENGTH*2]='\0';
		fflush(stdin);
		memset(buf3, 0x0, SHA_DIGEST_LENGTH*2);
    	memset(resultshaw256key, 0x0, SHA_DIGEST_LENGTH);
 
   		SHA256((unsigned char *)concatShawNonce1Nonce2, strlen(concatShawNonce1Nonce2), resultshaw256key);
 
    	for (i=0; i < SHA_DIGEST_LENGTH; i++) {
       		sprintf((char*)&(buf3[i*2]), "%02x", resultshaw256key[i]);
   		}
   		printf("*******SHA256 CALCULATED, THIS IS THE KEY *********: %s\n",buf3);


   		char buf4[SHA_DIGEST_LENGTH*2];
		unsigned char resultshaw256iv[SHA_DIGEST_LENGTH];

   		//AQUI CALCULO DESPUES EL IV DEL ENCRIPTADO, LOS 128 BITS(16 BYTES) DEL SHA256 DE NONCE1 Y NONCE2
		buf4[SHA_DIGEST_LENGTH*2]='\0';
		fflush(stdin);
		memset(buf4, 0x0, SHA_DIGEST_LENGTH*2);
    	memset(resultshaw256iv, 0x0, SHA_DIGEST_LENGTH);
 
  		SHA256((unsigned char *)concatNonce1Nonce2, strlen(concatNonce1Nonce2), resultshaw256iv);
 
    	for (i=0; i < SHA_DIGEST_LENGTH; i++) {
        	sprintf((char*)&(buf4[i*2]), "%02x", resultshaw256iv[i]);
    	}
    	char buf4cortado[18];
    	strncpy(buf4cortado,buf4,16);
    	buf4cortado[16]='\0';
    	//printf("*******SHA256 CALCULATED, THIS IS THE IV *********: %s\n",buf4);
    	printf("*******SHA256 CALCULATED, THIS IS THE IV *********: %s\n",buf4cortado);

    	//AQUI EMPIEZA YA EL DESENCRIPTADO
    	unsigned char *key = (unsigned char *)buf3;
    	unsigned char *iv = (unsigned char *)buf4cortado;
   		unsigned char *plaintext = (unsigned char *)concatNonce2mas1Comando;
		//A PARTIR DE AQUI VOY A DESENCRIPTAR LO QUE ME HAN MANDADO	
  		unsigned char decryptedtext[128];


		int decryptedtext_len;
  		decryptedtext_len = decrypt2(sms3.ciphertext, sms3.ciphertext_len, key, iv, decryptedtext);

  		
  		decryptedtext[decryptedtext_len] = '\0';

  		
  		printf("Decrypted text (in this case, the Nonce2+1 and the command) is:\n");
  		printf("%s\n", decryptedtext);	

  		//AQUI SEPARO LO QUE RECIBO
  		char comando[100];
  		char Nonce2mascharrecibido[32];

  		strncpy(Nonce2mascharrecibido,decryptedtext,4);
  		Nonce2mascharrecibido[4]='\0';
  		//printf("el nonce2masuno recibido es: %s\n", Nonce2mascharrecibido);
  		for(i=4;i<sizeof(decryptedtext);i++){
  			comando[i-4]=decryptedtext[i];
  		}
  		printf("The received command is: %s\n", comando);

  		//PASAR DE CHAR A INT PARA PODER RESTARLE UNO AL NUMERO Y COMPROBAR SI ES ESE EL QUE MANDE
  		int ultimodigito = (unsigned int) Nonce2mascharrecibido[3];
  		ultimodigito--;
  		Nonce2mascharrecibido[3]=(unsigned char)ultimodigito;
  		Nonce2mascharrecibido[4]='\0';
  		printf("The received Nonce2 number is:%s \n",Nonce2mascharrecibido);

    	if(strcmp(Nonce2char,Nonce2mascharrecibido)==0){
    		printf("*******NONCE2 IS CORRECT*********\n");
    		printf("*******SENDING THE NONCE+1 ENCRYPT AND THEN THE EXECUTION RESULT TO CLIENT*********\n");
    		
    		//AQUI TENGO QUE ENCRIPTAR NONCE1+1 CON LA KEY DE SIEMPRE
    		int nonce1mas;
    		nonce1mas = Nonce1+1;
    		char Nonce1mas1aencriptar[32];
    		sprintf(Nonce1mas1aencriptar,"%d",nonce1mas);
    		unsigned char *plaintextNonce1mas = (unsigned char *)Nonce1mas1aencriptar;
    		unsigned char ciphertextNonce1mas[128];

    		int ciphertext_len4;
    		ciphertext_len4=encrypt2(plaintextNonce1mas, strlen((char *)plaintextNonce1mas), key, iv, ciphertextNonce1mas);

    		printf("Ciphertext of Nonce1+1 is:\n");
    		BIO_dump_fp(stdout, (const char *)ciphertextNonce1mas,ciphertext_len4);

    		strcpy(sms4.id,sms1.id);
    		strcpy(sms4.ciphertext,ciphertextNonce1mas);
    		sms4.ciphertext_len=ciphertext_len4;
    		printf("Sending message with encrypted Nonce1+1 to the client *****\n");



    		//SI EL TIPO DEL MENSAJE ES 4 ES QUE TODO CORRECTO, SI ES 5 NOOOO
    		strcpy(sms4.messagetype,"4");
    		int n2;
  			if ((n2=write(sock, &sms4, sizeof(sms4)))!=sizeof(sms4))	/* send error */
			{
			#ifdef DEBUG
				printf("mal\n");
			#endif /* DEBUG */
				close(sock);
				return -1;
			}
				#ifdef DEBUG
					printf("***** RemoteShellD(%d): received %d bytes: `%s`\n", sock, cc, cmd);
				#endif

				strcat(comando, " 2>&1");
				#ifdef DEBUG
					printf("***** cmd: `%s`\n", comando); 
				#endif 
				if ((fp=popen(comando, "r"))==NULL)	/* stream open failed */
					return -1;

				//MIRAR EL ORDEN EN EL QUE SE DEBERIA MANDAR EL RESULTADO DEL COMANDO


				/* stream open successful */

				while ((fgets(result, resultSz, fp)) != NULL)	/* got execution result */
				{
					len = strlen(result);
					printf("***** sending %d bytes result to client: \n`%s` \n", len, result);

					if (write(sock, result, len) < 0)
					{ rc=-1;
			 		 break;
					}
				}
				fclose(fp);



    	}else{
    		printf("*******NONCE2 IS NOT CORRECT*********\n");
    		int n3;
    		strcpy(sms4.messagetype,"5");
  			if ((n3=write(sock, &mensaje2, sizeof(mensaje2)))!=sizeof(mensaje2))	/* send error */
			{
			#ifdef DEBUG
				printf("mal\n");
			#endif /* DEBUG */
				close(sock);
				return -1;
			}
			
    	}

    	

	
	}	


	}

	return rc;
}

/*------------------------------------------------------------------------
 * main - Concurrent TCP server 
 *------------------------------------------------------------------------
 */
int
main(int argc, char *argv[])
{
	int	 msock;			/* master server socket		*/
	int	 ssock;			/* slave server socket		*/
	int  portN;			/* port number to listen */
	struct sockaddr_in fromAddr;	/* the from address of a client	*/
	unsigned int  fromAddrLen;		/* from-address length          */
	int  prefixL, r;
	char *document;

	srand (getpid());

	if (argc==3){
		portN = atoi(argv[1]);
		document = argv[2];
	}else usage(argv[0]);

	msock = serverTCPsock(portN, 5);
	printf("*******INITIALIZING SERVER*********\n");


	(void) signal(SIGCHLD, reaper);

	while (1) 
	{
		fromAddrLen = sizeof(fromAddr);
		ssock = accept(msock, (struct sockaddr *)&fromAddr, &fromAddrLen);
		printf("aqui acepto el sockkk\n");
		if (ssock < 0) {
			if (errno == EINTR)
				continue;
			errmesg("accept error\n");
		}

		switch (fork()) 
		{
			case 0:		/* child */
				//printf("Estoy en el hijo del fork, esto arranca cuando un cliente se conecta\n");
				close(msock);
				r=RemoteShellD(ssock);
				close(ssock);
				exit(r);

			default:	/* parent */
				(void) close(ssock);
				break;
			case -1:
				errmesg("fork error\n");
		}
	}
	close(msock);
}


